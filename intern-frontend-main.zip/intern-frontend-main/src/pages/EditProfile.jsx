function EditProfile() {
  return <div>edit profile</div>;
}

export default EditProfile;
